package com.top.evenodd;

import java.util.Scanner;

public class EvenOddConsturctor {

	public EvenOddConsturctor(int num) {
		for(int i = 0; i<=num; i+=2) {
			System.out.print(i+" ");
		}
	}
	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int i = sc.nextInt();
		sc.close();
		
		// instead of creating an object with a reference variable, you can directly call constructor with the help of new keyword.
		// object is created when we use new keyword, so no use with the reference variable and it will be wasted.
		new EvenOddConsturctor(i);
		
	}

}
