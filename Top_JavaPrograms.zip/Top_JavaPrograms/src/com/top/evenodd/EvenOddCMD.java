package com.top.evenodd;

public class EvenOddCMD {
	public static void main(String args[]) {
		//command line arguments
		int n = Integer.parseInt(args[0]);
		
		long num = Long.parseLong(args[1]);
		System.out.println("Even numbers are: ");
		for(int i = 0; i<=n; i+=2) {
			System.out.print(i+" ");
		}
		System.out.println();
		System.out.println("Odd Numbers are: ");
		for(int i = 1; i<=num; i+=2) {
			System.out.print(i+" ");
		}
	}
}
