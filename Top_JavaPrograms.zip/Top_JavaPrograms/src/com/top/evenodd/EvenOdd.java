package com.top.evenodd;

import java.util.Scanner;

public class EvenOdd {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num = sc.nextInt();
		sc.close();
	
		// 1. for loop implementation type
		System.out.println("Even Numbers: ");
		for (int i = 0; i<=num;  ) {
			System.out.print(i+" ");
			i = i + 2;
		}
		// 2. for loop implementation type
		System.out.println();
		System.out.println("odd numbers: ");
		for (int i = 1; i<=num; i = i + 2) {
			System.out.print(i+" ");
		}
	}

}
