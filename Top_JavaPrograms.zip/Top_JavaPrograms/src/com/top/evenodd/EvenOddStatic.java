package com.top.evenodd;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class EvenOddStatic {
	static int even(int num) {
		
		for (int i = 0; i<=num; i++) {
			//logic
			int res = i % 2;
			if(res == 0) {
				System.out.print("Even are: "+i+" ");
			}
			if(res == 1) {
				System.out.println("odd are: "+i+" ");
			}
		}
		
		
		
		return num;
	}
	public static void main(String args[]) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter series end number: ");
		int i = Integer.parseInt(br.readLine());
		br.close();
		
		EvenOddStatic.even(i);
	}

}
