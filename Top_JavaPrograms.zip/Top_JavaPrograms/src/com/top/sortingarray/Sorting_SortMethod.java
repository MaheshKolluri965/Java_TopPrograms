package com.top.sortingarray;

import java.util.Arrays;

public class Sorting_SortMethod {
	public static void main(String args[]) {
		int[] arr = {52, 45, 32, 64, 12, 87, 78, 98, 23, 7};
		
		System.out.printf("original Array: %s", Arrays.toString(arr));
		Arrays.sort(arr);
		System.out.printf("\n\nsorted array: %s", Arrays.toString(arr));
		
		
	}

}
