package com.top.sortingarray;

/*	https://www.softwaretestinghelp.com/sort-arrays-in-java/
 
 	1. Using For Loops: You can use for loops to traverse the array and compare adjacent elements while traversing and 
 	putting them in order.
 	
	2. Using The Sort method: The Arrays class of  �java.util� package provides the sort method that takes an 
	array as an argument and sorts the array. This is a direct sorting method and you can sort an array with just one method call.
 
 
 	You can sort the array using manual sorting like using for loops. What you can do is use two for loops, 
 	one to traverse the array from the starting and another for loop inside the outer one to traverse the next element.

	In the body, you compare the adjacent elements and swap if they are not in order. 
	You can use a temporary variable for the swapping of elements.
 */



public class SortingArrayForLoop {
	public static void main(String args[]) {
		//defining array
		int[] arr = new int[] {52,45,32,64,12,87,78,98,23,7};
		int temp = 0;
		
		//printing original array
		// 1. if you use <= then length must be arr.length()-1
		// 2. if you use < then length must be arr.length
		System.out.println("original array:");
		for(int i = 0; i<arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		
		//Sorting using two for loops one for iteration and another for swapping 
		for(int i = 0; i<arr.length-1;i++) {
			for(int j = i+1; j<arr.length; j++) {
				if(arr[i] > arr[j]) {
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		//printing sorted array
		System.out.println();
		System.out.println("after sorting: ");
		for(int i = 0; i<= arr.length-1;i++) {
			System.out.print(arr[i]+" ");
		}	
		
		System.out.println();
		System.out.println("ascending order: ");
		for(int i = arr.length-1; i>=0; i--) {
			System.out.print(arr[i]+" ");
		}
	}
}
