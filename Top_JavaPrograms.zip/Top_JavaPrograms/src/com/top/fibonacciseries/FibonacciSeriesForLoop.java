package com.top.fibonacciseries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
//https://javatutoring.com/fibonacci-series-in-java/
/* 
 	FIBONACCI SERIES, coined by Leonardo Fibonacci(c.1175 � c.1250) is the collection of numbers in a sequence known as the Fibonacci Series 
 	where each number after the first two numbers is the sum of the previous two numbers. 
 	The series generally goes like 1, 1, 2, 3, 5, 8, 13, 21 and so on.
 */

/*
 * using For Loop
 	1) In Fibonacci series each number is addition of its two previous numbers.

	2) Read the n value using Scanner object sc.nextInt(), and store it in the variable n.

	3) For loop iterates from c=0 to c=n-1.

	a) For c=0 nextterm=0, for c=1 nexterm =1

	b) For c=2, nextterm=i+j=1(to get next value we are adding previous  two numbers), 
	   and �i� initialized to �j� (i.e i=1),�j� initialized to �nextterm� (i.e j=1), for c=3  nextterm =2, for c=4  nextterm=5 .
 */
public class FibonacciSeriesForLoop {
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter number of terms: ");
		int num = Integer.parseInt(br.readLine());
		
		int term1=0, term2=1, nextTerm;
		for (int i = 0; i<num; i++) {
			if (i<=1) {
				nextTerm=i;
			}else {
				nextTerm = term1 + term2;
				term1 = term2;
				term2 = nextTerm;
			}
			System.out.print(nextTerm+" ");
		}
	}
	
}
