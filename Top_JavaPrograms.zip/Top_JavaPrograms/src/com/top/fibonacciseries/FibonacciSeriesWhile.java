package com.top.fibonacciseries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class FibonacciSeriesWhile {

	void fibonacciSeries(int num) {
		int term1 = 0, term2= 1, nextTerm, i=0;
		while(i<num) {
			if(i<=1) {
				nextTerm = i;
			}else {
				nextTerm = term1 + term2;
				term1 = term2;
				term2 = nextTerm;
			}
			System.out.print (nextTerm+" ");
			i++;
		}
	}
	
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter number of terms: ");
		int num = Integer.parseInt(br.readLine());
		
		FibonacciSeriesRecursion fr = new FibonacciSeriesRecursion();
		fr.fibonacciSeries(num);	
	}

}
