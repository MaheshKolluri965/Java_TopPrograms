package com.top.fibonacciseries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class FibonacciSeriesRecursion {

	int term1 = 0, term2=1, nextTerm, i = 0;
	//one way
	public void fibonacciSeries(int num) {
		if(num>=0) {
			if(i<=1) {
				nextTerm = i;
			}else {
				nextTerm = term1 + term2;
				term1 = term2;
				term2 = nextTerm;
			}
			System.out.print(nextTerm+" ");
			i++;
			fibonacciSeries(--num);
		}	
	}
	//second way
	int term3 = 0, term4=1, next, j = 0;
	public void fibonacciSeries2(int num) {
		//logic change
		if(j<=num) {
			if(j<=1) {
				next = j;
			}else {
				next = term3 + term4;
				term3 = term4;
				term4 = next;
			}
			System.out.print(next+" ");
			j++;
			fibonacciSeries2(num);
		}	
	}
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter number of terms: ");
		int num = Integer.parseInt(br.readLine());
		
		FibonacciSeriesRecursion fr = new FibonacciSeriesRecursion();
		fr.fibonacciSeries(num);
		System.out.println();
		System.out.println("2nd series");
		fr.fibonacciSeries2(num);
		
		
	}
}
