package com.top.notes;
/*
 
 // 1. if you use <= then length must be arr.length()-1
 // 2. if you use < then length must be arr.length
 
 // here res will update each time when the method is called, so need to intialize outside the method while using recursion.
 //but rem remains same. since for rem the assignment is rem= num%10; which is within the method and no need to store this value.
 //int i = 1; -- while using recursion recommended ways are intializing outside the method or as a parameter.
	
 */





public class Notes {

	public Notes() {
		// TODO Auto-generated constructor stub
	}

}
