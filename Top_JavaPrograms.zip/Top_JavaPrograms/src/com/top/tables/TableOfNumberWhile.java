package com.top.tables;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TableOfNumberWhile {
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter number for table: ");
		int num = Integer.parseInt(br.readLine());
		System.out.println("enter end for table: ");
		int end = Integer.parseInt(br.readLine());
		
		int i = 1;
		while (i<=end) {
			System.out.println(num+" * "+i+" = "+i*num);
			i++;
		}
	}
}
