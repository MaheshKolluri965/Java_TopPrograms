package com.top.swaping;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 	Approach 3: Swapping the Values Using Operator (optimal method -  as here directly computations are 
 	carried on over bits instead of bytes as seen in previous two methods.) 

	- Bit-wise operators are used to perform manipulation of individual bits of a number. 
	  They can be used with any of the integral types (char, short, int, etc). 
	  They are used when performing update and query operations of Binary indexed tree.
 
	- This operator is binary operator, denoted by �^�. It returns bit by bit XOR of input values, i.e, 
	  if corresponding bits are different, it gives 1, else it gives 0.
	  
	  a = 5 = 0101 (In Binary)
	  b = 7 = 0111 (In Binary)

		Bitwise XOR Operation of 5 and 7
  				0101							0010							0101
			  ^ 0111							0111							0010
 				________						_______							______
  				0010  = 2 (In decimal)		     0101  = 5 (in decimal)			0111   = 7 (In decimal)	
 */
public class Swapping3Optimal {

	public void swap(int num1, int num2) {
		num1 = num1 ^ num2;
		num2 = num1 ^ num2;
		num1 = num2 ^ num1;
		
		System.out.println("After swapping");
		System.out.println("first: "+ num1 + " second: "+num2);	
	}
	
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter first number: ");
		int num1 = Integer.parseInt(br.readLine());
		System.out.println("enter second number: ");
		int num2 = Integer.parseInt(br.readLine());
		System.out.println("before Swapping");
		System.out.println("first: "+ num1 + " second: "+num2);
		
		Swapping3Optimal sw3 = new Swapping3Optimal();
		sw3.swap(num1, num2);
	}


}
