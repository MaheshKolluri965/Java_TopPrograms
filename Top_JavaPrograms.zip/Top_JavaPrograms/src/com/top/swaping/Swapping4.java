package com.top.swaping;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/*
 	Approach 4: Using arithmetic operators 
	
	- This is simplest way to swap the numbers without using any 3rd variable also swap the numbers in single line. 
	  In this approach will follow the simple expression to swap the numbers i.e.,  a = (a + b) � (b = a);  
	  Suppose we have value a=10, b=22, if we put these values in mentioned expression then it swap the values. 
	  It follows BODMAS rule then first bracket (a+b) i.e., (10+22)=32 
	  then it will solve another bracket (b=a) which simply put the value of a in b i.e., b=10. 
	  Now it will subtract 32-10 i.e., a=22. In this way we can swap the numbers easily.
	  
	  BODMAS RULE:
	  Let us consider, 3 x (2 + 4) + 52. Here, the BODMAS rule states we should calculate operations which is mentioned 
	  1. inside the Brackets first (2 + 4 = 6), 
	  2. then the Orders (52 = 25), 
	  3. then any Multiplication or Division (3 x 6 (the answer to the brackets) = 18),
	  4. and finally any Addition or Subtraction (18 + 25 = 43).
	  
 */
public class Swapping4 {
	public void swap(int num1, int num2) {
		
		num1 = (num1 + num2) - (num2 = num1);
		
		System.out.println("After swapping");
		System.out.println("first: "+ num1 + " second: "+num2);	
	}
	
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter first number: ");
		int num1 = Integer.parseInt(br.readLine());
		System.out.println("enter second number: ");
		int num2 = Integer.parseInt(br.readLine());
		System.out.println("before Swapping");
		System.out.println("first: "+ num1 + " second: "+num2);
		
		Swapping4 sw4 = new Swapping4();
		sw4.swap(num1, num2);
	}
}
