package com.top.swaping;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//https://www.geeksforgeeks.org/java-program-to-swap-two-numbers/

/* solution 1:
 	1. Creating an auxiliary memory cell in the memory.
	2. Without creating any auxiliary(additional) memory cell
	3. Using exclusive OR (Bitwise XOR) operator
 */
public class Swapping1 {

	static void swap(int num1, int num2) {
		int temp;

		temp = num1;
		num1 = num2;
		num2 = temp;
		System.out.println("After swapping");
		System.out.println("first: "+ num1 + " second: "+num2);	
	}
	
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter first number: ");
		int num1 = Integer.parseInt(br.readLine());
		System.out.println("enter second number: ");
		int num2 = Integer.parseInt(br.readLine());
		System.out.println("before Swapping");
		System.out.println("first: "+ num1 + " second: "+num2);
		swap(num1, num2);
	}
	
}
