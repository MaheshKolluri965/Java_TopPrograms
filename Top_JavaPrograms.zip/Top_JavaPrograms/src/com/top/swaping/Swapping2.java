package com.top.swaping;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 	Approach 2: Swapping the Values Without Using Third Variable by using sum and differences concepts of maths.

	Algorithms: There are 3 standard steps as listed below: 

	1. Difference of second number from the first number is stored in memory cell where first number was already stored.
	2. Sum of both the numbers  is stored in second memory cell(number).
	3. Difference of first number from the second is computed and stored in memory cell where at initial first value was stored.
 */
public class Swapping2 {

	public void swap(int num1, int num2) {
		num1 = num1 - num2;
		num2 = num1 + num2;
		num1 = num2 - num1;
		
		System.out.println("After swapping");
		System.out.println("first: "+ num1 + " second: "+num2);	
	}
	
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter first number: ");
		int num1 = Integer.parseInt(br.readLine());
		System.out.println("enter second number: ");
		int num2 = Integer.parseInt(br.readLine());
		System.out.println("before Swapping");
		System.out.println("first: "+ num1 + " second: "+num2);
		
		Swapping2 sw = new Swapping2();
		sw.swap(num1, num2);
	}

}
